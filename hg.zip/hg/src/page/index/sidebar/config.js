export default {
  propsDefault: {
    label: 'label',
    path: 'path',
    icon: 'icon',
    children: 'children',
    isOpen: 'isOpen'
  }
}
